# Activity 1 – Password generator flowchart

```mermaid
flowchart TD
    A([Start]) --> B[Display program title]
    B --> C[/Enter desired password length/]
    C --> D[/Choose lowercase, uppercase, digits, symbols/]
    D --> E{Length integer between 4 and 128?}
    E -- No --> X[Display validation error] --> C
    E -- Yes --> F{At least one category selected?}
    F -- No --> X
    F -- Yes --> G{Length >= selected category count?}
    G -- No --> X
    G -- Yes --> H[Select one random character from each category]
    H --> I[Fill remaining positions from combined pool]
    I --> J[Securely shuffle characters]
    J --> K[/Display generated password/]
    K --> L{Generate another?}
    L -- Yes --> C
    L -- No --> M([End])
```

The decisions prevent invalid input and ensure each selected character type appears at least once. Random choices and shuffling use Python's `secrets` module.
