# Activity 2 – Pseudocode

```
BEGIN
    DISPLAY "Secure Password Generator"
    REPEAT
        INPUT length
        INPUT includeLowercase, includeUppercase, includeDigits, includeSymbols
        IF length is not an integer OR length < 4 OR length > 128 THEN
            DISPLAY "Invalid length"
            CONTINUE
        ENDIF
        groups = empty list
        FOR EACH selected character category
            ADD that category's characters TO groups
        ENDFOR
        IF groups is empty OR length < number of groups THEN
            DISPLAY "Invalid selection"
            CONTINUE
        ENDIF
        passwordCharacters = empty list
        FOR EACH group IN groups
            APPEND one securely random character from group TO passwordCharacters
        ENDFOR
        pool = concatenate all groups
        WHILE size of passwordCharacters < length
            APPEND one securely random character from pool
        ENDWHILE
        SECURELY SHUFFLE passwordCharacters using Fisher-Yates
        DISPLAY joined passwordCharacters
        INPUT generateAnother
    UNTIL generateAnother = NO
END
```

**Inputs:** length and four yes/no category selections. **Output:** password of requested length containing every selected category. **Validation:** reject invalid length, no categories, or insufficient length. **Security:** use a cryptographically secure random generator.
